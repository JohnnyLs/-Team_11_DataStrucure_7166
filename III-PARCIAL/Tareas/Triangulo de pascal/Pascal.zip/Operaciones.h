#pragma once
class Operaciones {

private:
    int n;
public:
    int combinacion(int, int);
    int factorial(int);
};
